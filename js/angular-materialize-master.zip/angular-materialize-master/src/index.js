require('./angular-materialize');
module.exports = 'ui.materialize';
